/* File: function.cpp
 * Course: CS216-00x
 * Project: Coding Questions for Final Exam
 * Purpose: Provide the implementation of three functions.
 * Author: (your name)
 *
 */
#ifndef FUNCTIONS_CPP
#define FUNCTIONS_CPP

#include "functions.h"


//your implementation should start here...










#endif  /* FUNCTIONS_CPP */
