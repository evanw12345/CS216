/* File: card.cpp
 * Course: CS216-00x
 * Project: Lab 8 (as part of Project 2)
 * Purpose: the implementation of member functions for the Card class.
 * Author: (your name)
 */
#include "card.h"

// Default constructor marks card as invalid
Card::Card() {
}

// Alternate constructor
Card::Card(cSuits s, cPoints p) 
{
}

// access the card point value
Card::cPoints Card::getPoint() const
{
}

// access the card suit value
Card::cSuits Card::getSuit() const
{
}

// compare with another Card object passed in as parameter: other
// if the object your are working on has higher point than other, return 1;
// if the object your are working on has lower point than other, return -1;
// otherwise, return 0
int Card::compareTo(Card other) const
{
}

// Display a description of the Card object to standard output
// The output should look like:
//   the sign of suit, followed by the point, then followed by the sign of suit again   
void Card::print() const
{
}
