/* File: rank.cpp
 * Course: CS216-00x
 * Project: Lab 9 (as part of Project 2)
 * Purpose: the implementation of member functions for the Rank class.
 *
 */
#include <iostream>
#include "rank.h"

using namespace std;

// Default constructor.
Rank::Rank()
{
}

// Alternate constructor.
// Create a Rank object with specified ranking name and points.
Rank::Rank(hRanks r, rPoints p)
{
}

// access the hand ranking kind
Rank::hRanks Rank::getKind() const
{
}

// access the card point value of the corresponding ranking kind
Rank::rPoints Rank::getPoint() const
{
}

// Display a description of the hand-ranking category to standard output.
// The output should look like:
//   FourOfAKind( 4)
//   FullHouse(10)
//   Flush( A)
//   ...
void Rank::print() const
{
}

